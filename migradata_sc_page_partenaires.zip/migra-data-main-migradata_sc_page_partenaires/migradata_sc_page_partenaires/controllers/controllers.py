from odoo import http
from odoo.http import request


class PartenairesPage(http.Controller):

    @http.route(['/partenaires'], type='http', auth="public", website=True)
    def partenaires(self, page=1, **searches):
        request.env['ir.config_parameter'].sudo().set_param('accueil', '')

        contact = request.env['res.partner'].sudo().search([], order='sequence')
        partenaire_institutionnel = []
        contact_technique = []
        all_partner = []
        for partner in contact:
            if partner.partenaires.name == 'Partenaire institutionnel':
                partenaire_institutionnel.append(partner)
            if partner.partenaires.name == 'Partenaire technique':
                contact_technique.append(partner)
            if partner.partenaires.name == 'Partenaire institutionnel' or partner.partenaires.name == 'Partenaire technique':
                all_partner.append(partner)
        print(partenaire_institutionnel)
        values = {
            'contact_institutionnel': partenaire_institutionnel,
            'contact_technique': contact_technique,
            'contact_all': all_partner,
        }

        return request.render("migradata_sc_page_partenaires.page_partenaires", values)
