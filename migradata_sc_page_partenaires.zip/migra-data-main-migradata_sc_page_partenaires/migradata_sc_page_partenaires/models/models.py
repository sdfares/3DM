# -*- coding: utf-8 -*-

# from odoo import models, fields, api


# class migradata_sc_page_partenaires(models.Model):
#     _name = 'migradata_sc_page_partenaires.migradata_sc_page_partenaires'
#     _description = 'migradata_sc_page_partenaires.migradata_sc_page_partenaires'

#     name = fields.Char()
#     value = fields.Integer()
#     value2 = fields.Float(compute="_value_pc", store=True)
#     description = fields.Text()
#
#     @api.depends('value')
#     def _value_pc(self):
#         for record in self:
#             record.value2 = float(record.value) / 100
