# -*- coding: utf-8 -*-
# from odoo import http


# class PartnerNetwork(http.Controller):
#     @http.route('/partner_network/partner_network', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/partner_network/partner_network/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('partner_network.listing', {
#             'root': '/partner_network/partner_network',
#             'objects': http.request.env['partner_network.partner_network'].search([]),
#         })

#     @http.route('/partner_network/partner_network/objects/<model("partner_network.partner_network"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('partner_network.object', {
#             'object': obj
#         })
