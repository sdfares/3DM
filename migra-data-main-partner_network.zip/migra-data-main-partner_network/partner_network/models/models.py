# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
import odoo.addons.decimal_precision as dp
import time


class res_partner(models.Model):
    _inherit = "res.partner"

    facebook_url = fields.Char('Facebook')
    twitter_url = fields.Char('Twitter')
    youtube_url = fields.Char('Youtube')
    instagram_url = fields.Char('instagram')
    googleplus_url = fields.Char('Google+')
    linkedin_url = fields.Char('Linkedin')
    sequence = fields.Char('ordre')
    partenaires = fields.Many2one('res.partner.category', string='partenaires')


class users(models.Model):
    _inherit = 'res.users'

    request_id = fields.Many2many('datastore.demand', 'users_ids', 'attach_id3', 'doc_id',
                                  string="Request", invisible=1)
    category_id = fields.Many2one('res.partner.category', string='partenaires', related='partner_id.partenaires')


